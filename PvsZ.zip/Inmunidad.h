#pragma once
#include "Bono.h"
class Inmunidad : public Bono
{
public:
	Inmunidad(int px, int py);
	~Inmunidad();
};

