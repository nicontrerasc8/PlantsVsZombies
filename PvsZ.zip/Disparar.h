#pragma once
#include "Bono.h"
class Disparar : public Bono
{
public:
	Disparar(int px, int py);
	~Disparar();
};

