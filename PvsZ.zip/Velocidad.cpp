#include "Velocidad.h"

Velocidad::Velocidad(int px, int py) : Bono(px, py){}
Velocidad::~Velocidad(){}
