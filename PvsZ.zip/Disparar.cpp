#include "Disparar.h"

Disparar::Disparar(int px, int py) : Bono(px, py)
{
}

Disparar::~Disparar()
{
}
