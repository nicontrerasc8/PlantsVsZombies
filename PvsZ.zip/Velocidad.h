#pragma once
#include "Bono.h"
class Velocidad : public Bono
{
public:
	Velocidad(int px, int py);
	~Velocidad();
};

