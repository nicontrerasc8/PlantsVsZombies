#include "Inmunidad.h"

Inmunidad::Inmunidad(int px, int py) : Bono(px,py){}

Inmunidad::~Inmunidad()
{
}
